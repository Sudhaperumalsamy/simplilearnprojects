package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
@JsonIgnoreProperties(ignoreUnknown = true)
@Embeddable
@Table(name = "attendancedetails")
@Data
@AllArgsConstructor
@Entity
public class AttendanceDetails {
 
	
	@Column(name="id")
	@Id 
	public int id;
	@Column(name="employee_id")
	public String empid;
	@Column(name="visitcount")
	public String count;
	@Column(name="attendance_status")
	public String attendance;
	@Column(name="employee_name")
	public String employee_name;
	@Column(name="portfolio")
	public String team_name;
	@Column(name="created_date")
	public String created_date;
	
	
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getAttendance() {
		return attendance;
	}
	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}
	
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getTeam_name() {
		return team_name;
	}
	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}
	public String getCreated_date() {
		return created_date;
	}
	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	}
