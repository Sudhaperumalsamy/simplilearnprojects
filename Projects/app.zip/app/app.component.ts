import { Component, OnInit } from '@angular/core';
import { ChartData } from './bar-chart/bar-chart.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    title = 'TVS Application';
    cardDisplayData1 = '';
    cardDisplayData2 = '';
    cardDisplayData3 = '';

    barChartData: ChartData[] = [];

    cardData1 = {
      "01-01-2021" : 200,
      "02-01-2021" : 250,
      "03-01-2021" : 400,
      "04-01-2021" : 350,
      "05-01-2021" : 150,
      "06-01-2021" : 220,
      "07-01-2021" : 260
    }

    cardData2 = {
      "01-01-2021" : 200,
      "02-01-2021" : 250,
      "03-01-2021" : 400,
      "04-01-2021" : 350,
      "05-01-2021" : 150,
      "06-01-2021" : 220,
      "07-01-2021" : 260
    }

    cardData3 = {
      "01-01-2021" : 200,
      "02-01-2021" : 250,
      "03-01-2021" : 400,
      "04-01-2021" : 350,
      "05-01-2021" : 150,
      "06-01-2021" : 220,
      "07-01-2021" : 260
    }

    constructor() {
      this.getDataForDate('card1', '01-01-2021')
      this.getDataForDate('card2', '01-01-2021')
      this.getDataForDate('card3', '01-01-2021')
    }


    ngOnInit() {

      const tempBarChart: ChartData = {
        category: 'Sudha',
        data : {
          labels: ['01/01/2021', '01/01/2021', '02/01/2021', '03/01/2021', '04/01/2021'],
          datasets: [
            {
              label: 'Sales',
              backgroundColor: 'rgb(75, 192, 192, 0.2)',
              borderColor: 'rgb(75, 192, 192, 1)',
              borderWidth: 1,
              hoverBackgroundColor: 'rgb(75, 192, 192, 0.4)',
              hoverBorderColor: 'rgb(75, 192, 192, 1)',
              data: [102, 206, 301, 132, 111]

            }
          ]
        }
      }

      this.barChartData.push(tempBarChart);
    }

    dateChanged(data) {
        console.log(data.value);
    }

    getDataForDate(card, date) {
        if (card === 'card1') {
          this.cardDisplayData1 = this.cardData1[date];
        } else if (card === 'card2') {
          this.cardDisplayData2 = this.cardData2[date];
        } else if (card === 'card3') {
          this.cardDisplayData3 = this.cardData3[date];
        } else {
          return 0;
        }
    }
}

