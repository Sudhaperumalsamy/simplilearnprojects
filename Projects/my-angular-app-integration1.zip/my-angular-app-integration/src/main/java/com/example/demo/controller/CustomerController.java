package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.service.SalesService;
import com.example.demo.model.Sales;
@CrossOrigin(origins="*")
@RequestMapping("/api")
@RestController
public class CustomerController {
	@Autowired
	
	private  SalesService service;
	@GetMapping("/sale1")
	public ResponseEntity<List<Sales>> getSalesService(){
		List<Sales> sales=null;
		
	
	 sales= service.readExcelFile("data/sample_data.xlsx");
	 
	     System.out.println("sales>>"+sales);
		return ResponseEntity.ok().body(sales);
		//String jsonString =service.convertMapToJson(sales);
				//body(sales);
		
	}
	
	
	
//	@GetMapping("/sale1")
//	public List<Sales>  getSalesService(){
//		
//		List<Sales> sales=null;
//		
//		
//		 sales= service.readExcelFile("data/sample_data.xlsx");
//		 
//		 System.out.println("sales>>"+sales);
//		 
           
//		
//		
//		return sales;
//		
//	}
	
}
	

	

