package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.AttendanceDetails;
import com.example.demo.model.UserList;

public interface AttendanceRepository extends JpaRepository<UserList, Integer>  {

	void save(AttendanceDetails details);

}
