package com.example.demo.model;

public class Inputdata {
	private Parameter param;
	private Paging paging;
	private Sorting sorting;
	public Parameter getParam() {
		return param;
	}
	public void setParam(Parameter param) {
		this.param = param;
	}
	public Paging getPaging() {
		return paging;
	}
	public void setPaging(Paging paging) {
		this.paging = paging;
	}
	public Sorting getSorting() {
		return sorting;
	}
	public void setSorting(Sorting sorting) {
		this.sorting = sorting;
	}
	@Override
	public String toString() {
		return "Inputdata [param=" + param + ", paging=" + paging + ", sorting=" + sorting + "]";
	}
	

}
