package com.example.demo.model;

import com.example.demo.model.*;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;

//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;

//import javax.persistence.Table;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer id;
	public String record_count;
	public String userlist;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRecord_count() {
		return record_count;
	}

	public void setRecord_count(String record_count) {
		this.record_count = record_count;
	}

	public String getUserlist() {
		return userlist;
	}

	public void setUserlist(String userlist) {
		this.userlist = userlist;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((record_count == null) ? 0 : record_count.hashCode());
		result = prime * result + ((userlist == null) ? 0 : userlist.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (record_count == null) {
			if (other.record_count != null)
				return false;
		} else if (!record_count.equals(other.record_count))
			return false;
		if (userlist == null) {
			if (other.userlist != null)
				return false;
		} else if (!userlist.equals(other.userlist))
			return false;
		return true;
	}
	

	@Override
	public String toString() {
		return "User [id=" + id + ", record_count=" + record_count + ", userlist=" + userlist + "]";
	}

	public User() {
		// TODO Auto-generated constructor stub
	}

}