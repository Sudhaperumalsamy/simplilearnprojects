import { Component, Input, OnInit } from '@angular/core';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})

export class BarChartComponent implements OnInit {

  @Input() data : ChartData[];
  sudhaChart = [];
  sureshChart = [];

  ngOnInit() {
    this.data.forEach( data => {
      Chart.defaults.global.defaultFontFamily = 'Roboto';
      Chart.defaults.global.defaultFontSize = 12;
      switch(data.category) {
          case 'Sudha' :
            this.sudhaChart = new Chart('sudha-chart', {
              type: 'bar',
              data: data.data
            })
            case 'Suresh' :
            this.sureshChart = new Chart('suresh-chart', {
              type: 'bar',
              data: data.data
            })
      }
    })
  }

}

export interface ChartData {
  category: string;
  data: ChartDataSet;
}

export interface ChartDataSet {
  datasets: ChartDataCount[];
  labels: string[];
}

export interface ChartDataCount {
  data: number[];
  label?: string;
  borderColor: string[] | string;
  backgroundColor: string[] | string;
  hoverBackgroundColor?: string[] | string;
  borderWidth?: number;
  hoverBorderColor?: string;
}

