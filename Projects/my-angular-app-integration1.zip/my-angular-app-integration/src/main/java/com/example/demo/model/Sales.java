package com.example.demo.model;

public class Sales {
	int SRNO;
	String Sale_Person;
	String Customer;
	double Loan_Amount;
	String Purchase_Date;
	
	
	public Sales() {
		super();
	}
	
	
	
	
	public Sales(int sRNO, String sale_Person, String customer, double loan_Amount, String purchase_Date) {
		super();
		SRNO = sRNO;
		Sale_Person = sale_Person;
		Customer = customer;
		Loan_Amount = loan_Amount;
		Purchase_Date = purchase_Date;
	}




	public int getSRNO() {
		return SRNO;
	}




	public void setSRNO(int sRNO) {
		SRNO = sRNO;
	}




	public String getSale_Person() {
		return Sale_Person;
	}




	public void setSale_Person(String sale_Person) {
		Sale_Person = sale_Person;
	}




	public String getCustomer() {
		return Customer;
	}




	public void setCustomer(String customer) {
		Customer = customer;
	}




	public double getLoan_Amount() {
		return Loan_Amount;
	}




	public void setLoan_Amount(double loan_Amount) {
		Loan_Amount = loan_Amount;
	}




	public String getPurchase_Date() {
		return Purchase_Date;
	}




	public void setPurchase_Date(String purchase_Date) {
		Purchase_Date = purchase_Date;
	}




	@Override
	public String toString() {
		return "FiletoPojo [SRNO=" + SRNO + ", Sale_Person=" + Sale_Person + ", Customer=" + Customer + ", Loan_Amount="
				+ Loan_Amount + ", Purchase_Date=" + Purchase_Date + "]";
	}
	
	


	
}
