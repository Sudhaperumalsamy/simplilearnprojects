package com.example.demo.service;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.example.demo.model.Sales;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class SalesService{
	
	    // Step 1: Read Excel File into Java List Objects
	   // List<Sales> customers = readExcelFile("data/sample_data.xlsx");
	    
	    // Step 2: Convert Java Objects to JSON String
	 //   String jsonString = convertObjects2JsonString(customers);
	    
	   // System.out.println(jsonString);

	  
	  /**
	   * Read Excel File into Java List Objects
	   * 
	   * @param filePath
	   * @return
	   */
	  public  List<Sales> readExcelFile(String filePath){
	    try {
	      FileInputStream excelFile = new FileInputStream(new File(filePath));
	        Workbook workbook = new XSSFWorkbook(excelFile);
	     
	        Sheet sheet = workbook.getSheet("Sheet1");
	        Iterator<Row> rows = sheet.iterator();
	        
	        List<Sales> lstCustomers = new ArrayList<Sales>();
	        
	        int rowNumber = 0;
	        while (rows.hasNext()) {
	          Row currentRow = rows.next();
	          
	          // skip header
	          if(rowNumber == 0) {
	            rowNumber++;
	            continue;
	          }
	          
	          Iterator<Cell> cellsInRow = currentRow.iterator();
	          
	          Sales cust = new Sales();
	          
	          int cellIndex = 0;
	          while (cellsInRow.hasNext()) {
	            Cell currentCell = cellsInRow.next();
	            
	            if(cellIndex==0) { // SRNO
	              cust.setSRNO((int)currentCell.getNumericCellValue());
	            } else if(cellIndex==1) { //Sales Person
	              cust.setSale_Person(currentCell.getStringCellValue());
	            } else if(cellIndex==2) { // Customer
	              cust.setCustomer(currentCell.getStringCellValue());
	            } else if(cellIndex==3) { // Loan Amount
	              cust.setLoan_Amount(currentCell.getNumericCellValue());
	            }else if(cellIndex==4) {  // Purchase Date
	            	 if (DateUtil.isCellDateFormatted(currentCell)) {
	                     SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	                    cust.setPurchase_Date(dateFormat.format(currentCell.getDateCellValue()));
	            }
	            }
	           
	            cellIndex++;
	          }
	          
	          lstCustomers.add(cust);
	        }
	        // Close WorkBook
	        workbook.close();
	        
	        return lstCustomers;
	        } catch (IOException e) {
	          throw new RuntimeException("FAIL! -> message = " + e.getMessage());
	        }
	    
	  }
	  public static void myfunction(Sales sale_Person) {
		  {
			System.out.println(sale_Person);  
		  }
	  }
	  
	  /**
	   * Convert Java Objects to JSON String
	   * 
	   * @param customers
	   * @param fileName
	 * @return 
	   */
	//  public static String convertObjects2JsonString(List<Sales> customers) {
	      //ObjectMapper mapper = new ObjectMapper();
	     // String jsonString = " ";
	      
	      //try {
	        //jsonString = mapper.writeValueAsString(customers);
	      //} catch (JsonProcessingException e) {
	        //e.printStackTrace();
	      //}
	      
	      //return jsonString; 
	      //public 

	    	//    @Test
	    	   public  static  void convertMapToJson(List<Sales> customers) {
	    	       Map<String, String> elements = new HashMap<>();
	    	      elements.put("","");
	    	       elements.put("","");
	    	        elements.put("Key3", "Value3");
              //  JSONObject json = new JSONObject(elements);

	    	       System.out.println("elemnts"+elements);
	    	     //  return elements;
	    	  }
	//  }

	

	
}
	


