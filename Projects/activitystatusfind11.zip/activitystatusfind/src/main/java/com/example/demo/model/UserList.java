package com.example.demo.model;



import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Embeddable
@Table(name = "activitycode")
@Data
@AllArgsConstructor
@Entity
public class UserList {
	@Column(name="id")
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer id;
	@Column(name="created_by")
	public String CreatedBy;
	@Column(name="extension_modified_by")
	public String Extension_ModifiedBy;
	@Column(name="prospect_activity_id")
    public String ProspectActivityId;
	@Column(name="related_prospect_id")
    public String RelatedProspectId;
	@Column(name="activity_type")
    public String ActivityType;
	@Column(name="activity_event")
    public String ActivityEvent;
	@Column(name="created_on")
    public String CreatedOn;
	@Column(name="created_by_name")
    public String CreatedByName;
	@Column(name="created_by_email_address")
    public String CreatedByEmailAddress;
	@Column(name="modified_on")
    public String ModifiedOn;
	@Column(name="modified_by")
    public String ModifiedBy;
	@Column(name="modified_by_email_address")
    public String ModifiedByEmailAddress;
	@Column(name="modified_by_name")
    public String ModifiedByName;
	@Column(name="mx_Custom_4")
    public String mx_Custom_4;
	@Column(name="mx_Custom_7")
    public String mx_Custom_7;
	@Column(name="mx_Custom_13")
    public String mx_Custom_13;
	@Column(name="mx_Custom_14")
    public String mx_Custom_14;
	@Column(name="mx_Custom_15")
    public String mx_Custom_15;
	@Column(name="mx_Custom_16")
    public String mx_Custom_16;
	@Column(name="mx_Custom_17")
    public String mx_Custom_17;
	@Column(name="mx_Custom_18")
    public String mx_Custom_18;
	@Column(name="mx_Custom_19")
    public String mx_Custom_19;
//    public List<Userlist> list ;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	public String getProspectActivityId() {
		return ProspectActivityId;
	}
	public void setProspectActivityId(String prospectActivityId) {
		ProspectActivityId = prospectActivityId;
	}
	public String getRelatedProspectId() {
		return RelatedProspectId;
	}
	public void setRelatedProspectId(String relatedProspectId) {
		RelatedProspectId = relatedProspectId;
	}
	public String getActivityType() {
		return ActivityType;
	}
	public void setActivityType(String activityType) {
		ActivityType = activityType;
	}
	public String getActivityEvent() {
		return ActivityEvent;
	}
	public void setActivityEvent(String activityEvent) {
		ActivityEvent = activityEvent;
	}
	public String getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(String createdOn) {
		CreatedOn = createdOn;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
		}
	public String getCreatedByName() {
		return CreatedByName;
	}
	public void setCreatedByName(String createdByName) {
		CreatedByName = createdByName;
	}
	public String getCreatedByEmailAddress() {
		return CreatedByEmailAddress;
	}
	public void setCreatedByEmailAddress(String createdByEmailAddress) {
		CreatedByEmailAddress = createdByEmailAddress;
	}
	public String getModifiedOn() {
		return ModifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		ModifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return ModifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		ModifiedBy = modifiedBy;
	}
	public String getExtension_ModifiedBy() {
		return Extension_ModifiedBy;
	}
	public void setExtension_ModifiedBy(String extension_ModifiedBy) {
		Extension_ModifiedBy = extension_ModifiedBy;
	}
	public String getModifiedByEmailAddress() {
		return ModifiedByEmailAddress;
	}
	public void setModifiedByEmailAddress(String modifiedByEmailAddress) {
		ModifiedByEmailAddress = modifiedByEmailAddress;
	}
	public String getModifiedByName() {
		return ModifiedByName;
	}
	public void setModifiedByName(String modifiedByName) {
		ModifiedByName = modifiedByName;
	}
	public String getMx_Custom_4() {
		return mx_Custom_4;
	}
	public void setMx_Custom_4(String mx_Custom_4) {
		this.mx_Custom_4 = mx_Custom_4;
	}
	public String getMx_Custom_7() {
		return mx_Custom_7;
	}
	public void setMx_Custom_7(String mx_Custom_7) {
		this.mx_Custom_7 = mx_Custom_7;
	}
	public String getMx_Custom_13() {
		return mx_Custom_13;
	}
	public void setMx_Custom_13(String mx_Custom_13) {
		this.mx_Custom_13 = mx_Custom_13;
	}
	public String getMx_Custom_14() {
		return mx_Custom_14;
	}
	public void setMx_Custom_14(String mx_Custom_14) {
		this.mx_Custom_14 = mx_Custom_14;
	}
	public String getMx_Custom_15() {
		return mx_Custom_15;
	}
	public void setMx_Custom_15(String mx_Custom_15) {
		this.mx_Custom_15 = mx_Custom_15;
	}
	public String getMx_Custom_16() {
		return mx_Custom_16;
	}
	public void setMx_Custom_16(String mx_Custom_16) {
		this.mx_Custom_16 = mx_Custom_16;
	}
	public String getMx_Custom_17() {
		return mx_Custom_17;
	}
	public void setMx_Custom_17(String mx_Custom_17) {
		this.mx_Custom_17 = mx_Custom_17;
	}
	public String getMx_Custom_18() {
		return mx_Custom_18;
	}
	public void setMx_Custom_18(String mx_Custom_18) {
		this.mx_Custom_18 = mx_Custom_18;
	}
	public String getMx_Custom_19() {
		return mx_Custom_19;
	}
	public void setMx_Custom_19(String mx_Custom_19) {
		this.mx_Custom_19 = mx_Custom_19;
	}
	
	
	
	@Override
	public String toString() {
		return "Userlist [ProspectActivityId=" + ProspectActivityId + ", RelatedProspectId=" + RelatedProspectId
				+ ", ActivityType=" + ActivityType + ", ActivityEvent=" + ActivityEvent + ", CreatedOn=" + CreatedOn
				+ ",CreatedByName=" + CreatedByName + ", CreatedByEmailAddress="
				+ CreatedByEmailAddress + ", ModifiedOn=" + ModifiedOn + ", ModifiedBy=" + ModifiedBy
				+ ", Extension_ModifiedBy=" + Extension_ModifiedBy + ", ModifiedByEmailAddress="
				+ ModifiedByEmailAddress + ", ModifiedByName=" + ModifiedByName + ", mx_Custom_4=" + mx_Custom_4
				+ ", mx_Custom_7=" + mx_Custom_7 + ", mx_Custom_13=" + mx_Custom_13 + ", mx_Custom_14=" + mx_Custom_14
				+ ", mx_Custom_15=" + mx_Custom_15 + ", mx_Custom_16=" + mx_Custom_16 + ", mx_Custom_17=" + mx_Custom_17
				+ ", mx_Custom_18=" + mx_Custom_18 + ", mx_Custom_19=" + mx_Custom_19 + "]";
	}
	public UserList(String prospectActivityId, String relatedProspectId, String activityType, String activityEvent,
			String createdOn, String createdBy, String createdByName, String createdByEmailAddress, String modifiedOn,
			String modifiedBy, String extension_ModifiedBy, String modifiedByEmailAddress, String modifiedByName,
			String mx_Custom_4, String mx_Custom_7, String mx_Custom_13, String mx_Custom_14, String mx_Custom_15,
			String mx_Custom_16, String mx_Custom_17, String mx_Custom_18, String mx_Custom_19) {
		super();
		ProspectActivityId = prospectActivityId;
		RelatedProspectId = relatedProspectId;
		ActivityType = activityType;
		ActivityEvent = activityEvent;
		CreatedOn = createdOn;
		CreatedBy = createdBy;
		CreatedByName = createdByName;
		CreatedByEmailAddress = createdByEmailAddress;
		ModifiedOn = modifiedOn;
		ModifiedBy = modifiedBy;
		Extension_ModifiedBy = extension_ModifiedBy;
		ModifiedByEmailAddress = modifiedByEmailAddress;
		ModifiedByName = modifiedByName;
		this.mx_Custom_4 = mx_Custom_4;
		this.mx_Custom_7 = mx_Custom_7;
		this.mx_Custom_13 = mx_Custom_13;
		this.mx_Custom_14 = mx_Custom_14;
		this.mx_Custom_15 = mx_Custom_15;
		this.mx_Custom_16 = mx_Custom_16;
		this.mx_Custom_17 = mx_Custom_17;
		this.mx_Custom_18 = mx_Custom_18;
		this.mx_Custom_19 = mx_Custom_19;
	}
	public UserList() {
		// TODO Auto-generated constructor stub
	}
    
	
    

}