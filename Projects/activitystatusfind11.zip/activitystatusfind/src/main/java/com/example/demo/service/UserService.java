package com.example.demo.service;

import java.util.ArrayList;
import java.text.SimpleDateFormat;

import java.util.Date;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.example.demo.model.AttendanceDetails;
import com.example.demo.model.User;
import com.example.demo.model.UserList;
import com.example.demo.repository.AttendanceRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.repository.UserlistRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;


@CrossOrigin(origins = "*")


@RestController
public class UserService {
	
	RestTemplate restTemplate = new RestTemplate();
	private static final long MILLIS_IN_A_DAY = 1000 * 60 * 60 * 24;
	private static final String ResponseEntity = null;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserlistRepository userlistRepository;
	@Autowired
	AttendanceRepository attendancerepository;
   
	@Autowired
	JdbcTemplate jdbc;
	 

	public String callApi() 
	{
	Map<String, String> mapmessage = new HashMap<>();
	List<List<JSONObject>> finaldata= new ArrayList<List<JSONObject>>();
	String useractivitydetails ;
	JSONObject js;
	JSONParser jsonParser = new JSONParser();
	ObjectMapper objectMapper = new ObjectMapper();
      //Set pretty printing of json
    objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		try {
		  String query="select LSQActivitycode from tbl_mst_activity where portfolio='Direct Sales'";
	        List<Map<String, Object>> categoryList = jdbc.queryForList(query);
	        		for (Map<String, Object> mapofdata : categoryList)
	        		{
	        		List<JSONObject> jsonObject = getdetails(mapofdata.get("LSQActivitycode").toString());
	        		System.out.println("User details"+jsonObject);
	        			if(jsonObject != null) {
					   finaldata.add(jsonObject); 
				   								}
	          
	        		}
	        
				}
	        catch (Exception ex) {
			ex.printStackTrace();
		}
	  return finaldata.toString();
	}

	private List<JSONObject> getdetails(String activitycode) {
		ResponseEntity<String> resultcount = null;
//		List<String> data = new ArrayList<String>();
		
		
		
		Map<String,String> map = new HashMap<String, String>();
		List<JSONObject> returndata = new ArrayList<JSONObject>();
		//ResponseEntity<UserList> resultUsers = null;
		User user = new User();
		AttendanceDetails details = new AttendanceDetails();
	    Map<String, Integer> resultMap = new HashMap<String, Integer>();
		try {
	     	String firsturl = "https://api-in21.leadsquared.com/v2/ProspectActivity.svc/CustomActivity/RetrieveByActivityEvent?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8";
			JSONArray json = new JSONArray();
			JSONObject obj = new JSONObject();

			HttpHeaders headers = new HttpHeaders();
			headers.add("Accept", MediaType.APPLICATION_JSON.toString());
			headers.add("Content-Type", MediaType.APPLICATION_JSON.toString());
			ObjectMapper mapper = new ObjectMapper();
			JSONParser jsonParser = new JSONParser();
			Date todayDate = new Date();
		    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String today = formatter.format(todayDate);//dd-MM
		    
		    long oneDayBefore = (todayDate.getTime() - MILLIS_IN_A_DAY);
            String predate = formatter.format(oneDayBefore);
		    JSONObject finalObj = new JSONObject();
	        JSONObject parameterObj = new JSONObject();
	        JSONObject pagingObj = new JSONObject();
	        JSONObject sortingObj = new JSONObject();
	                parameterObj.put("FromDate", "2021-06-26 00:00:00");
                    parameterObj.put("ToDate", "2021-06-27 00:00:00");
	                //parameterObj.put("FromDate", predate+" 00:00:00");
	                //parameterObj.put("ToDate", today+" 00:00:00");
	                parameterObj.put("ActivityEvent", activitycode);
	                parameterObj.put("RemoveEmptyValue", true);
	                pagingObj.put("PageIndex", 0);
	                pagingObj.put("PageSize", 0);
	                sortingObj.put("ColumnName", "ModifiedOn");
	                sortingObj.put("Direction", 1);
	                finalObj.put("Parameter", parameterObj);
	                finalObj.put("Paging", pagingObj);
	                finalObj.put("Sorting", sortingObj);
	         HttpEntity request = new HttpEntity(finalObj, headers);
	         resultcount = restTemplate.exchange(firsturl, HttpMethod.POST, request, String.class);
	         if(resultcount!=null) {
	        	JSONParser parser = new JSONParser();  
		        obj = (JSONObject) parser.parse(resultcount.getBody()); 
		   
		       List<UserList> list = (List<UserList>) obj.get("List");
		     //  System.out.println(list);
		        ObjectMapper objectMapper = new ObjectMapper();
		        //Set pretty printing of json
		        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		         //1. Convert List of Person objects to JSON
		        String arrayToJson = objectMapper.writeValueAsString(list);
		       // System.out.println("1. Convert List of person objects to JSON :");
		       // System.out.println(arrayToJson);
		        //2. Convert JSON to List of Person objects
		        //Define Custom Type reference for List<Person> type
		        TypeReference<List<UserList>> mapType = new TypeReference<List<UserList>>() {};
		        List<UserList> jsonToPersonList = objectMapper.readValue(arrayToJson, mapType);
		       // System.out.println("\n2. Convert JSON to List of person objects :");
		       //  Print list of person objects output using Java 8
		     //jsonToPersonList.forEach(System.out::println);
	   	       for (UserList userList : jsonToPersonList) {
	   				userlistRepository.save(userList);
	  			}

		        String attendancequery="select activitycode.activity_event,user_info.id,activitycode.modified_by_name,user_info.team_name,activitycode.created_on,user_info.empid from activitycode,user_info where activitycode.extension_modified_by = user_info.id and user_info.team_name='Direct Sales' and activitycode.activity_event ="+"'"+activitycode+"' and activitycode.created_on like '2021-06-26%'"; // "+"'"+predate+"%'"; //date yyyy-mm-dd 
		   
		                                                                                                                                                                                                                                                                                                                                                                                                              //like"+"'"frmdate+"%'"; 
		        List attendancelist = jdbc.queryForList(attendancequery);
			     for (Object o : attendancelist) {
			        Map m = (Map) o;
			        
			        if (resultMap.containsKey(m.get("empid"))) {
			        	
			            resultMap.put(m.get("empid").toString(), resultMap.get(m.get("empid")) + 1);
			           
			        } 
			        else 
			        {
			            resultMap.put(m.get("empid").toString(), 1);
			        }
			        
			     }
			     
			     String attenquery="select activitycode.activity_event,user_info.id,activitycode.modified_by_name,user_info.team_name,activitycode.created_on,user_info.empid from activitycode,user_info where activitycode.extension_modified_by = user_info.id and user_info.team_name='Direct Sales' and activitycode.activity_event ="+"'"+activitycode+"' and activitycode.created_on like '2021-06-26%'";  //"+"'"+predate+"%'\; 
			     List attenlist = jdbc.queryForList(attenquery);
			
			     Iterator<String> it = resultMap.keySet().iterator();       //keyset is a method  
			     while(it.hasNext())  
			     {  
			    	 JSONObject data = new JSONObject();
			     String key=it.next();  
			     map.put("empid", key);
			     map.put("count", resultMap.get(key).toString());
			     String name=null;
			     String created_date=null;
			     String team_name=null;
			    
			     for (Object o : attenlist) {
				        Map n = (Map) o;
				       if(key.equals(n.get("empid").toString())) {
				        	    name= n.get("modified_by_name").toString();
						        created_date=n.get("created_on").toString();
						        team_name=n.get("team_name").toString(); 	
				        }}
			 	  if(resultMap.get(key)>0) {
			    	map.put("attendance", "P") ;
			        map.put("employee_name",name);
				    map.put("created_date",created_date);
				    map.put("team_name", team_name);
			     }
			     else {
			    	  map.put("attendance", "");
			    	  map.put("employee_name",name);
					  map.put("created_date",created_date);
					  map.put("team_name", team_name);
			     }
			     data.putAll(map);
			   //  System.out.println("data"+data);
				 TypeReference<AttendanceDetails> mType = new TypeReference<AttendanceDetails>() {};

			        AttendanceDetails jsonToPersonL =objectMapper.readValue(data.toJSONString(), mType);
			       // System.out.println("json+"+jsonToPersonL.getEmployee_name());
			       
			        details.setAttendance(jsonToPersonL.getAttendance());
			        details.setCount(jsonToPersonL.getCount());
			        details.setCreated_date(jsonToPersonL.getCreated_date());
			        details.setEmpid(jsonToPersonL.getEmpid());
			        details.setEmployee_name(jsonToPersonL.getEmployee_name());
			        details.setTeam_name(jsonToPersonL.getTeam_name());
			        attendancerepository.save(details);
			        returndata.add(data);
			       // attendancerepository.save(details);
			     } 	
	        }
	        else {
	        	JSONObject data = new JSONObject();
	        	  returndata.add(data);
	        }
	        
		     
		    } 
		catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return returndata;
	}}

