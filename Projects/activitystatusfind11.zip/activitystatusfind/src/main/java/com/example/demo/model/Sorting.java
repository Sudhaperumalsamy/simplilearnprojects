package com.example.demo.model;

public class Sorting {
	private String 	ColumnName;
	private String ModifiedOn;
	private String Direction;
	public String getColumnName() {
		return ColumnName;
	}
	public void setColumnName(String columnName) {
		ColumnName = columnName;
	}
	public String getModifiedOn() {
		return ModifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		ModifiedOn = modifiedOn;
	}
	public String getDirection() {
		return Direction;
	}
	public void setDirection(String direction) {
		Direction = direction;
	}
	@Override
	public String toString() {
		return "Sorting [ColumnName=" + ColumnName + ", ModifiedOn=" + ModifiedOn + ", Direction=" + Direction + "]";
	}
	
}
