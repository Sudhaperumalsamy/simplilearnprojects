package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.service.UserService;

@CrossOrigin(origins = "*")
@RestController
public class UserController {
    @Autowired
	private UserService service;
	
    @RequestMapping(value = "/callApi", produces = { "application/json",
	"application/xml" }, method = RequestMethod.GET)
	public  Object getUserService(){
	  Object users=null;
		
		users=  service.callApi();
	 
	     System.out.println("users>>"+users);
		return users;
		
}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//@RequestMapping(value = "/getschemedetail", method = RequestMethod.GET)

	//public String getschemedetail() {

		//ResponseEntity<String> response = null;
		//try {

			//String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/Users.Get?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8";
			// String finalUrl = DBControllerConstants.GETCARDDETAILS_URL +
			// "?name=getSchemeDetails" + "&key="
			// + DBControllerConstants.CARD_KRY;

			//URI uridata = UriComponentsBuilder.fromHttpUrl(finalUrl).queryParam("data",obj).build().toUri();

		//	HttpHeaders requestHeaders = new HttpHeaders();
		//	requestHeaders.setContentType(MediaType.APPLICATION_JSON);

		//	HttpEntity<HashMap<String, String>> requestEntity = new HttpEntity<HashMap<String, String>>(requestHeaders);
		//	response = restTemplatescheme.postForEntity(uridata, requestEntity, String.class);
	//	} catch (HttpClientErrorException ex) {

		//	Logger logger = Logger.getLogger(User.class.getName());
		//	logger.log(Level.SEVERE, "hi", ex.getMessage());

		//	if (ex.getRawStatusCode() == 400) {
			//	throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Bad request " + ex);
		//	} else if (ex.getRawStatusCode() == 401) {
				//throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,
				//		"Hearder Token unauthorised in getschemedetail()");
			//} else {
		////		throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
		//				"Unexpeted error occured in getschemedetail() " + ex);
	//		}
	//	}
	//	return response.getBody();
	//}
//
//	@GetMapping("/callApi")
//	public Object callApi() {
//
//		String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/Users.Get?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8";
//		try {
//			List<Map<String, Object>> datas = restTemplatescheme.getForObject(finalUrl, List.class);
//
//			for (Map<String, Object> data : datas) {
//				
//			
//				
//				User userData = new User();
//				userData.setEmailAddress(data.get("EmailAddress").toString());
//				userData.setFirstName(data.get("FirstName").toString());
//				userData.setID(data.get("ID").toString());
//				userData.setIsPhoneCallAgent((boolean) data.get("IsPhoneCallAgent"));
//				userData.setLastName(data.get("LastName").toString());
//				userData.setRole(data.get("Role").toString());
//				userData.setStatusCode((Integer) data.get("StatusCode"));
//				//userData.setOrgId("null");
//				if (data.get("Tag") != null)
//					userData.setTag(data.get("Tag").toString());
//				else
//					userData.setTag("null");
//			//	System.out.println(userData);
//				public Object retrieveApi(@PathVariable String userId) {
//					String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/User/Retrieve/ByUserId?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8&userId="+userId;
//				userRepository.save(userData);
//				}
//		
//				
//				}
//			}
//			return datas;
//		}
//		catch (Exception e) {
//			System.out.println(e);
//			return e;
//		}
//
//	}
	//@GetMapping("/updatedata/{userId}")
//	public Object retrieveApi(@PathVariable String userId) {
//		//System.out.println(userId);
//
//		String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/User/Retrieve/ByUserId?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8&userId="+userId;
//		System.out.println(finalUrl);
//		try {
//			List<Map<String, Object>> datas = restTemplatescheme.getForObject(finalUrl, List.class);
//      System.out.println(finalUrl);
//      for (Map<String, Object> data : datas) {
//				User userData = new User();
//				userData.setEmailAddress(data.get("EmailAddress").toString());
//				userData.setFirstName(data.get("FirstName").toString());
//				userData.setID(data.get("ID").toString());
//				userData.setIsPhoneCallAgent((boolean) data.get("IsPhoneCallAgent"));
//				userData.setLastName(data.get("LastName").toString());
//				userData.setRole(data.get("Role").toString());
//				userData.setStatusCode((Integer) data.get("StatusCode"));
//				
//				if (data.get("Tag") != null)
//					userData.setTag(data.get("Tag").toString());
//				userData.setID(userId);
//				userData.setOrgId(data.get("OrgId").toString());
//				System.out.println(datas);
//				userRepository.save(userData);
//
//      }
//			return datas;
//		} catch (Exception e) {
//			System.out.println(e);
//			return e;
//		}

	//}
	

//}