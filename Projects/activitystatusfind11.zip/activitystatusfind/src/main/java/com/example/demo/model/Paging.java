package com.example.demo.model;

public class Paging {
	private String PageIndex;
	private String PageSize;
	public String getPageIndex() {
		return PageIndex;
	}
	public void setPageIndex(String pageIndex) {
		PageIndex = pageIndex;
	}
	public String getPageSize() {
		return PageSize;
	}
	public void setPageSize(String pageSize) {
		PageSize = pageSize;
	}
	@Override
	public String toString() {
		return "Paging [PageIndex=" + PageIndex + ", PageSize=" + PageSize + "]";
	}
	
	
}
