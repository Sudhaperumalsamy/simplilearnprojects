package com.example.demo.model;

public class Parameter {
	private String FromDate;
	private String ToDate;
	private String ActivityEvent;
	private String RemoveEmptyValue;
	public String getFromDate() {
		return FromDate;
	}
	public void setFromDate(String fromDate) {
		FromDate = fromDate;
	}
	public String getToDate() {
		return ToDate;
	}
	public void setToDate(String toDate) {
		ToDate = toDate;
	}
	public String getActivityEvent() {
		return ActivityEvent;
	}
	public void setActivityEvent(String activityEvent) {
		ActivityEvent = activityEvent;
	}
	public String getRemoveEmptyValue() {
		return RemoveEmptyValue;
	}
	public void setRemoveEmptyValue(String removeEmptyValue) {
		RemoveEmptyValue = removeEmptyValue;
	}
	@Override
	public String toString() {
		return "Parameter [FromDate=" + FromDate + ", ToDate=" + ToDate + ", ActivityEvent=" + ActivityEvent
				+ ", RemoveEmptyValue=" + RemoveEmptyValue + "]";
	}
	

}
