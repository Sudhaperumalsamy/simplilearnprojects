package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_info")
public class User {
	@Id
	String ID;
	String FirstName;
	String LastName;
	String EmailAddress;
	String Role;
	Integer StatusCode;
	String Tag;
	Boolean IsPhoneCallAgent;
	String OrgId;
	String CompanyName;
	String ManagerUserId;
	String City;
	String State;
    String ManagerName;
    String PhoneMain;
    String PhoneMobile;
    String Designation; 
    String Department;
    String OfficeLocationName;
    String SalesRegions;
    String EmpID; 
    String TeamId;
    String TeamName;
	String CreatedOn;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getEmailAddress() {
		return EmailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		EmailAddress = emailAddress;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public Integer getStatusCode() {
		return StatusCode;
	}
	public void setStatusCode(Integer statusCode) {
		StatusCode = statusCode;
	}
	public String getTag() {
		return Tag;
	}
	public void setTag(String tag) {
		Tag = tag;
	}
	public Boolean getIsPhoneCallAgent() {
		return IsPhoneCallAgent;
	}
	public void setIsPhoneCallAgent(Boolean isPhoneCallAgent) {
		IsPhoneCallAgent = isPhoneCallAgent;
	}
	public String getOrgId() {
		return OrgId;
	}
	public void setOrgId(String orgId) {
		OrgId = orgId;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public String getManagerUserId() {
		return ManagerUserId;
	}
	public void setManagerUserId(String managerUserId) {
		ManagerUserId = managerUserId;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getManagerName() {
		return ManagerName;
	}
	public void setManagerName(String managerName) {
		ManagerName = managerName;
	}
	public String getPhoneMain() {
		return PhoneMain;
	}
	public void setPhoneMain(String phoneMain) {
		PhoneMain = phoneMain;
	}
	public String getPhoneMobile() {
		return PhoneMobile;
	}
	public void setPhoneMobile(String phoneMobile) {
		PhoneMobile = phoneMobile;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getDepartment() {
		return Department;
	}
	public void setDepartment(String department) {
		Department = department;
	}
	public String getOfficeLocationName() {
		return OfficeLocationName;
	}
	public void setOfficeLocationName(String officeLocationName) {
		OfficeLocationName = officeLocationName;
	}
	public String getSalesRegions() {
		return SalesRegions;
	}
	public void setSalesRegions(String salesRegions) {
		SalesRegions = salesRegions;
	}
	
	public String getEmpID() {
		return EmpID;
	}
	public void setEmpID(String empID) {
		EmpID = empID;
	}
	public String getTeamId() {
		return TeamId;
	}
	public void setTeamId(String teamId) {
		TeamId = teamId;
	}
	public String getTeamName() {
		return TeamName;
	}
	public void setTeamName(String teamName) {
		TeamName = teamName;
	}
	public String getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(String createdOn) {
		CreatedOn = createdOn;
	}
	@Override
	public String toString() {
		return "User [ID=" + ID + ", FirstName=" + FirstName + ", LastName=" + LastName + ", EmailAddress="
				+ EmailAddress + ", Role=" + Role + ", StatusCode=" + StatusCode + ", Tag=" + Tag
				+ ", IsPhoneCallAgent=" + IsPhoneCallAgent + ", OrgId=" + OrgId + ", CompanyName=" + CompanyName
				+ ", ManagerUserId=" + ManagerUserId + ", City=" + City + ", State=" + State + ", ManagerName="
				+ ManagerName + ", PhoneMain=" + PhoneMain + ", PhoneMobile=" + PhoneMobile + ", Designation="
				+ Designation + ", Department=" + Department + ", OfficeLocationName=" + OfficeLocationName
				+ ", SalesRegions=" + SalesRegions + ", EmpID=" + EmpID + ", TeamId=" + TeamId + ", TeamName="
				+ TeamName + ", CreatedOn=" + CreatedOn + "]";
	}
	public User(String iD, String firstName, String lastName, String emailAddress, String role, Integer statusCode,
			String tag, Boolean isPhoneCallAgent, String orgId, String companyName, String managerUserId, String city,
			String state, String managerName, String phoneMain, String phoneMobile, String designation,
			String department, String officeLocationName, String salesRegions, String empID, String teamId,
			String teamName, String createdOn) {
		super();
		ID = iD;
		FirstName = firstName;
		LastName = lastName;
		EmailAddress = emailAddress;
		Role = role;
		StatusCode = statusCode;
		Tag = tag;
		IsPhoneCallAgent = isPhoneCallAgent;
		OrgId = orgId;
		CompanyName = companyName;
		ManagerUserId = managerUserId;
		City = city;
		State = state;
		ManagerName = managerName;
		PhoneMain = phoneMain;
		PhoneMobile = phoneMobile;
		Designation = designation;
		Department = department;
		OfficeLocationName = officeLocationName;
		SalesRegions = salesRegions;
		EmpID = empID;
		TeamId = teamId;
		TeamName = teamName;
		CreatedOn = createdOn;
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	
	

}
