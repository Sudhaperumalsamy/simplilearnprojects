package com.example.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@CrossOrigin(origins = "*")
//@RequestMapping("https://api-in21.leadsquared.com/v2/UserManagement.svc/Users.Get?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8")
@RestController
public class UserService {
 //  @Autowired
	//private UserService service;
	public String firsturl= "https://api-in21.leadsquared.com/v2/UserManagement.svc/Users.Get?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8";
	public String secondurl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/User/Retrieve/ByUserId?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8&userId=";
	@Autowired
	RestTemplate restTemplatescheme;
	
	
	@Autowired
	UserRepository userRepository;

	@Bean
	public RestTemplate restTemplatescheme(RestTemplateBuilder builder) {
		return builder.build();
	}

	//@GetMapping("/callApi")
	    public Map<String, Object> callApi() {
		List<Map<String, Object>> datas =null;
		int i = 0;
		
	
		//User productSKUresponse = null;
		Map<String, Object> mapmessage = new HashMap<>();
		
		try {
			
			List<Map<String, Object>> datas1 = restTemplatescheme.getForObject(firsturl, List.class);

			for (Map<String, Object> data1 : datas1) {
				User userData = new User();
	while(i < 10) {
		
	
				userData.setID(data1.get("ID").toString());
			//	@GetMapping("/updatedata")
				//System.out.println(data1.get("ID").toString());
			//	public Object retrieveApi() {
				String prevUrl = secondurl+data1.get("ID");
					//if(userData.setID==userData.userID)
					
					
			      datas= restTemplatescheme.getForObject(prevUrl, List.class);

						for (Map<String, Object> data : datas) {
							//if(!data.get("UserId").toString().equals("960d6e3e-7591-11eb-b68d-02506fc2b3ce")) {
					
						if(data.get("IsPhoneCallAgent")!=null)
				         userData.setIsPhoneCallAgent((boolean) data.get("IsPhoneCallAgent"));
						//else
							//userData.setIsPhoneCallAgent("null");
						if(data.get("EmailAddress")!=null)
							userData.setEmailAddress(data.get("EmailAddress").toString());
						else
							 userData.setEmailAddress("null");
						if(data.get("FirstName")!=null)
				         userData.setFirstName(data.get("FirstName").toString());
						else
							userData.setFirstName("null");
						if(data.get("LastName")!=null)
						userData.setLastName(data1.get("LastName").toString());
						else
							userData.setLastName("null");
						if(data.get("Role")!=null)
				       userData.setRole(data.get("Role").toString());
						else
						userData.setRole("null");
					//	if (data1.get("Tag") != null)	
						if (data1.get("StatusCode") != null)
							 userData.setStatusCode((Integer) data.get("StatusCode"));
						else
							userData.setStatusCode(0);
						if (data.get("OrgId") != null)
							 userData.setOrgId(data.get("OrgId").toString());
						else
							userData.setOrgId("null");
				 
				if (data1.get("Tag") != null)
					userData.setTag(data1.get("Tag").toString());
				else
					userData.setTag("null");
				if (data.get("City") != null)
				userData.setCity(data.get("City").toString());
				else
					userData.setCity("null");
				if (data.get("CompanyName") != null)
				userData.setCompanyName(data.get("CompanyName").toString());
				else
					userData.setCompanyName("null");
				if(data.get("CreatedOn")!=null)
				userData.setCreatedOn(data.get("CreatedOn").toString());
				else
					userData.setCreatedOn("null");
			     if(data.get("mx_Custom_1")!=null) {
			    	 
			    		userData.setEmpID(data.get("mx_Custom_1").toString()); 
			     }
			
				else
					userData.setEmpID("null");
				if (data.get("ManagerName") != null)
     			userData.setManagerName(data.get("ManagerName").toString());
      			else
				userData.setManagerName("null");
				if(data.get("Designation")!=null)
				userData.setDesignation(data.get("Designation").toString()); 
				else
					userData.setDesignation("null");
				if(data.get("PhoneMain")!=null)
				userData.setPhoneMain(data.get("PhoneMain").toString());
				else
				userData.setPhoneMain("null");
				if(data.get("OfficeLocationName")!=null)
				userData.setOfficeLocationName(data.get("OfficeLocationName").toString());
				else
					userData.setOfficeLocationName("null");
				if(data.get("ManagerUserId")!=null)
				userData.setManagerUserId(data.get("ManagerUserId").toString());
				else
					userData.setManagerUserId("null");	
				if(data.get("PhoneMobile")!=null)
				userData.setPhoneMobile(data.get("PhoneMobile").toString());
				else
					userData.setPhoneMobile("null");
				if(data.get("Department")!=null)
					userData.setDepartment(data.get("Department").toString());
				else
					userData.setDepartment("null");
				if(data.get("SalesRegions")!=null)
				userData.setSalesRegions(data.get("SalesRegions").toString());
				else
					userData.setSalesRegions("null");	
				if(data.get("TeamId")!=null)
				userData.setTeamId(data.get("TeamId").toString());
				else
					userData.setTeamId("null");	
				if(data.get("TeamName")!=null)
				userData.setTeamName(data.get("TeamName").toString());
				else
					userData.setTeamName("null");
				if(data.get("State")!=null)
				userData.setState(data.get("State").toString());
				else
					userData.setState("null");	
				
				userRepository.save(userData);
				
				mapmessage.put("user"+i, datas);
				i = i+1;
			
			
							}
	}					
						}
			
										
	//			}
			
			
			 
		} catch (Exception e) {
			System.out.println(e.getMessage());
		//	return e.toString();
		}
		
		return mapmessage;
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//@RequestMapping(value = "/getschemedetail", method = RequestMethod.GET)

	//public String getschemedetail() {

		//ResponseEntity<String> response = null;
		//try {

			//String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/Users.Get?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8";
			// String finalUrl = DBControllerConstants.GETCARDDETAILS_URL +
			// "?name=getSchemeDetails" + "&key="
			// + DBControllerConstants.CARD_KRY;

			//URI uridata = UriComponentsBuilder.fromHttpUrl(finalUrl).queryParam("data",obj).build().toUri();

		//	HttpHeaders requestHeaders = new HttpHeaders();
		//	requestHeaders.setContentType(MediaType.APPLICATION_JSON);

		//	HttpEntity<HashMap<String, String>> requestEntity = new HttpEntity<HashMap<String, String>>(requestHeaders);
		//	response = restTemplatescheme.postForEntity(uridata, requestEntity, String.class);
	//	} catch (HttpClientErrorException ex) {

		//	Logger logger = Logger.getLogger(User.class.getName());
		//	logger.log(Level.SEVERE, "hi", ex.getMessage());

		//	if (ex.getRawStatusCode() == 400) {
			//	throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Bad request " + ex);
		//	} else if (ex.getRawStatusCode() == 401) {
				//throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,
				//		"Hearder Token unauthorised in getschemedetail()");
			//} else {
		////		throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
		//				"Unexpeted error occured in getschemedetail() " + ex);
	//		}
	//	}
	//	return response.getBody();
	//}
//
//	@GetMapping("/callApi")
//	public Object callApi() {
//
//		String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/Users.Get?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8";
//		try {
//			List<Map<String, Object>> datas = restTemplatescheme.getForObject(finalUrl, List.class);
//
//			for (Map<String, Object> data : datas) {
//				
//			
//				
//				User userData = new User();
//				userData.setEmailAddress(data.get("EmailAddress").toString());
//				userData.setFirstName(data.get("FirstName").toString());
//				userData.setID(data.get("ID").toString());
//				userData.setIsPhoneCallAgent((boolean) data.get("IsPhoneCallAgent"));
//				userData.setLastName(data.get("LastName").toString());
//				userData.setRole(data.get("Role").toString());
//				userData.setStatusCode((Integer) data.get("StatusCode"));
//				//userData.setOrgId("null");
//				if (data.get("Tag") != null)
//					userData.setTag(data.get("Tag").toString());
//				else
//					userData.setTag("null");
//			//	System.out.println(userData);
//				public Object retrieveApi(@PathVariable String userId) {
//					String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/User/Retrieve/ByUserId?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8&userId="+userId;
//				userRepository.save(userData);
//				}
//		
//				
//				}
//			}
//			return datas;
//		}
//		catch (Exception e) {
//			System.out.println(e);
//			return e;
//		}
//
//	}
	//@GetMapping("/updatedata/{userId}")
//	public Object retrieveApi(@PathVariable String userId) {
//		//System.out.println(userId);
//
//		String finalUrl = "https://api-in21.leadsquared.com/v2/UserManagement.svc/User/Retrieve/ByUserId?accessKey=u$rf768da83a0db0595f86de16ce00b7b32&secretKey=ee1fe1d82f47269d4d7d73eac18315564d5336c8&userId="+userId;
//		System.out.println(finalUrl);
//		try {
//			List<Map<String, Object>> datas = restTemplatescheme.getForObject(finalUrl, List.class);
//      System.out.println(finalUrl);
//      for (Map<String, Object> data : datas) {
//				User userData = new User();
//				userData.setEmailAddress(data.get("EmailAddress").toString());
//				userData.setFirstName(data.get("FirstName").toString());
//				userData.setID(data.get("ID").toString());
//				userData.setIsPhoneCallAgent((boolean) data.get("IsPhoneCallAgent"));
//				userData.setLastName(data.get("LastName").toString());
//				userData.setRole(data.get("Role").toString());
//				userData.setStatusCode((Integer) data.get("StatusCode"));
//				
//				if (data.get("Tag") != null)
//					userData.setTag(data.get("Tag").toString());
//				userData.setID(userId);
//				userData.setOrgId(data.get("OrgId").toString());
//				System.out.println(datas);
//				userRepository.save(userData);
//
//      }
//			return datas;
//		} catch (Exception e) {
//			System.out.println(e);
//			return e;
//		}

	//}
	

//}