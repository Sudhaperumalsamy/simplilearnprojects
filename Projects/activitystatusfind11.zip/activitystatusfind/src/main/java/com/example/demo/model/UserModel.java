package com.example.demo.model;

import java.util.ArrayList;

public abstract class UserModel {

	ArrayList<UserList> List = new ArrayList<UserList>();

	public ArrayList<UserList> getList() {
		return List;
	}

	public void setList(ArrayList<UserList> list) {
		List = list;
	}

}
